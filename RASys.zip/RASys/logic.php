<?php

require_once("dbconnect.php");

if($_SERVER["REQUEST_METHOD"] == "POST"){



    $name=$_POST['Username'];
   
    $password=$_POST['Password'];

    
    $query="SELECT * FROM `users` WHERE username='$name' and password='$password'";
    $result = mysqli_query($conn,$query);

    $row = mysqli_fetch_array($result);
    if(mysqli_num_rows($result)==1){
    if($row['id']==1){

        setcookie('admin', $row['id'], time() + 86400 , '/');

        header("Location:admin.php");
    }
    else{
        setcookie('employe', $row['id'], time() + 86400 , '/');

        header("Location:user.php");

    }
}
else{
    echo "Enter valid Data";
}
}

?>

