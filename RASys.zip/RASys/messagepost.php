<?php

require_once('dbconnect.php');
if (isset($_GET['submit'])) {

    $id = $_GET['userid'];
    $message = $_GET['message'];
    foreach ($id as $id) {
        $query = "insert into message (Uid,Message)Values('$id','$message')";
        mysqli_query($conn, $query);
    }


    header('Location:message.php');
}
