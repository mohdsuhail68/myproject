<?php

require_once("dbconnect.php");

if(isset($_GET['checkin'])){
   $i=0;
   $query="insert into attendance (Uid,date,CheckIn,CheckOut) values ('".$_COOKIE['employe']."','".date('d_m_y')."','".date('H:i:sa')."','$i')";
   mysqli_query($conn,$query);
   header("Location:attendence.php");
}
if(isset($_GET['checkout'])){
   $query="update attendance Set CheckOut='".date('H:i:sa')."' where date='".date('d_m_y')."'";
   mysqli_query($conn,$query);
   header("Location:attendence.php");
}
?>