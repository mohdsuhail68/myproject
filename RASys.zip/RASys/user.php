<?php
if(!isset($_COOKIE['employe'])){
    header('Location:login.php');
}
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Employe Interface</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
  <div class=" container-fluid  bg-secondary">
        <div class="row text-center justify-content-center">
            <h1>RABBIT<span> InfoTech</span>
        </div>
    </div>
    <nav class=" ml-auto  navbar navbar-expand-lg navbar-dark bg-primary">

        <a class="navbar-brand ml-auto " href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="user.php">Home <span class="sr-only">(current)</span></a>

                <li class="nav-item active">
                    <a class="nav-link" href="attendence.php">Attendence<span class="sr-only">(current)</span></a>
                </li>

                <li class="nav-item active">
                    <a class="nav-link" href="adminMessage.php">Admin Message<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="logouts.php">Logout<span class="sr-only">(current)</span></a>
                </li>

            </ul>
        </div>

        </div>
    </nav>
    <div class="container">
        <div class="row ">
            <h3 style="font-weight:bolder; margin-left: 30vw; position:absolute">Welcome Employe</hh3>
        </div>
    </div>
    <br>
    <br>
    <br>
    <div class="container">
      <div class="row">
      <?php
      $conn = new mysqli("localhost", "root", "","rabbit");
      $query="select * from users";
      $result= mysqli_query($conn,$query);
      
      
      ?>
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Given Task</th>
                    <th scope="col">Task Assign Time </th>
                    <th scope="col">Update Your Task Status </th>

                </tr>
            </thead>
            <tbody style="background-color:lightgray">
                <tr>
                

                
                   <?php while($row=mysqli_fetch_array($result)){
                    if($row['id']==$_COOKIE['employe']){ ?>
                    <th scope="col"><?= $row['id'];?></th>
                    <th scope="col"><?= $row['username'];?></th>
                    <th scope="col"><?= $row['message'];?></th>
                    <th scope="col"><?= $row['taskassigntime'];?></th>
                    <th scope="col"><a href="updatetask.php?id=<?=$row['id']?>">Update Task</a></th>
                </tr>
            <?php } }?>
                 
           
                </thead>

            </tbody>
        </table>
      </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>