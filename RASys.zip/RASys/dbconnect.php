<?php
$conn = new mysqli("localhost", "root", "","rabbit");
date_default_timezone_set("Asia/Calcutta");
?>