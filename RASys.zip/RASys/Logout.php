<?php
$conn = new mysqli("localhost", "root", "","rabbit");
setcookie('admin',' ', time() - 86400,'/');
header("Location:login.php");
?>