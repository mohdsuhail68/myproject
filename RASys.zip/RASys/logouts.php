<?php
$conn = new mysqli("localhost", "root", "","rabbit");
setcookie("employe",'',time() - 86400,'/');
header("Location:login.php");
?>